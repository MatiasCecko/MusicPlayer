package com.example.musicplayerv2;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;
import android.graphics.Color;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class ListMusicActivity extends AppCompatActivity {
    private static final int REQUEST_PERMISSION = 99;

    private ArrayList<Song> allSongs = new ArrayList<>();
    private ArrayList<Song> filteredSongs = new ArrayList<>();
    private SongAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_music);

        ListView lvSongs     = findViewById(R.id.lvSongs);
        SearchView searchView= findViewById(R.id.searchView);


        // Spremenimo barvo besedila in namiga na belo
        int searchTextId = searchView.getContext().getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView searchText = searchView.findViewById(searchTextId);
        if (searchText != null) {
            searchText.setTextColor(Color.WHITE);
            searchText.setHintTextColor(Color.WHITE);
        }

        // Spremenimo magnifying glass ikono v belo
        int searchIconId = searchView.getContext().getResources()
                .getIdentifier("android:id/search_mag_icon", null, null);
        ImageView searchIcon = searchView.findViewById(searchIconId);
        if (searchIcon != null) {
            searchIcon.setColorFilter(Color.WHITE);
        }

        // Spremenimo "X" ikono (gumb za brišanje) v belo
        int closeBtnId = searchView.getContext().getResources()
                .getIdentifier("android:id/search_close_btn", null, null);
        ImageView closeBtn = searchView.findViewById(closeBtnId);
        if (closeBtn != null) {
            closeBtn.setColorFilter(Color.WHITE);
        }

        // Spodnja črta (search plate) nastavljena na #1A1A1A
        int searchPlateId = searchView.getContext().getResources()
                .getIdentifier("android:id/search_plate", null, null);
        if (searchPlateId != 0) {
            android.view.View searchPlate = searchView.findViewById(searchPlateId);
            if (searchPlate != null && searchPlate.getBackground() != null) {
                searchPlate.getBackground().setColorFilter(
                        Color.parseColor("#1A1A1A"),
                        PorterDuff.Mode.SRC_IN);
            }
        }


        // 1) Nastavimo adapter na "filteredSongs"
        adapter = new SongAdapter(this, filteredSongs);
        lvSongs.setAdapter(adapter);

        // 2) Naložimo pesmi (po preveritvi pravic)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_AUDIO}, REQUEST_PERMISSION);
            } else {
                loadSongs();
            }
        } else {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION);
            } else {
                loadSongs();
            }
        }

        // 3) Ko kliknemo na pesem, pošljemo cel seznam + trenutni indeks
        lvSongs.setOnItemClickListener((parent, view, pos, id) -> {
            Intent i = new Intent(ListMusicActivity.this, MusicPlayerActivity.class);
            i.putExtra("songs", allSongs);
            // "pos" je index znotraj filteredSongs, poiščemo originalni index
            Song chosen = filteredSongs.get(pos);
            int originalIndex = allSongs.indexOf(chosen);
            i.putExtra("position", originalIndex);
            startActivity(i);
        });

        // 4) SearchView: vsakič ko uporabnik tipka, filtriramo
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterSongs(query);
                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterSongs(newText);
                return true;
            }
        });
    }

    private void loadSongs() {
        ContentResolver cr = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = cr.query(uri, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int idxTitle = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int idxData  = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            do {
                String title = cursor.getString(idxTitle);
                String path  = cursor.getString(idxData);
                Song s = new Song(title, path);
                allSongs.add(s);
            } while (cursor.moveToNext());
            cursor.close();
        }
        // na začetku prikažemo vse
        filteredSongs.clear();
        filteredSongs.addAll(allSongs);
        adapter.notifyDataSetChanged();
    }

    private void filterSongs(String text) {
        String lower = text.toLowerCase().trim();
        filteredSongs.clear();
        if (lower.isEmpty()) {
            filteredSongs.addAll(allSongs);
        } else {
            for (Song s : allSongs) {
                if (s.getTitle().toLowerCase().contains(lower)) {
                    filteredSongs.add(s);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_PERMISSION
                && grantResults.length>0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadSongs();
        } else {
            Toast.makeText(this, "Brez pravic ni pesmi", Toast.LENGTH_SHORT).show();
        }
    }
}
