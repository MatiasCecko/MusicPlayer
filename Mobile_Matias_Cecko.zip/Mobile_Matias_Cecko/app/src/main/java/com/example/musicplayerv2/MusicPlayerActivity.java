package com.example.musicplayerv2;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

public class MusicPlayerActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tvTime, tvDuration, tvTitle;
    SeekBar seekBarTime, seekBarVolume;
    Button btnPlay, btnNext, btnPrev;

    MediaPlayer musicPlayer;
    ArrayList<Song> songs;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // 1) PREJMEMO SEZNAM PESMI IN IZBRANI INDEKS
        songs = (ArrayList<Song>) getIntent().getSerializableExtra("songs");
        position = getIntent().getIntExtra("position", 0);
        if (songs == null || songs.isEmpty()) {
            Toast.makeText(this, "Ni pesmi za predvajanje", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // 2) NALOGA VSEH VIEW-EV
        tvTime       = findViewById(R.id.tvTime);
        tvDuration   = findViewById(R.id.tvDuration);
        tvTitle      = findViewById(R.id.tvTitle);
        seekBarTime  = findViewById(R.id.seekBarTime);
        seekBarVolume= findViewById(R.id.seekBarVolume);
        btnPlay      = findViewById(R.id.btnPlay);
        btnNext      = findViewById(R.id.btnNext);
        btnPrev      = findViewById(R.id.btnPrev);

        btnPlay.setOnClickListener(this);
        btnNext.setOnClickListener(this);
        btnPrev.setOnClickListener(this);

        // 3) USTVARIMO IN NASTAVIMO MediaPlayer
        musicPlayer = new MediaPlayer();
        musicPlayer.setOnCompletionListener(mp -> {
            // ko pesem konča, pojdi na naslednjo
            position = (position + 1) % songs.size();
            playSongAt(position);
        });

        // 4) ZAŽENEMO PRVO PESM
        playSongAt(position);

        // 5) VOLUME SEEKBAR
        seekBarVolume.setProgress(50);
        seekBarVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int prog, boolean fromUser) {
                float vol = prog / 100f;
                musicPlayer.setVolume(vol, vol);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });

        // 6) ČASOVNA OKNA
        seekBarTime.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int prog, boolean fromUser) {
                if (fromUser) {
                    musicPlayer.seekTo(prog);
                    sb.setProgress(prog);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });

        // 7) POSODOBITEV TEKAJOČEGA ČASA
        new Thread(() -> {
            while (musicPlayer != null) {
                if (musicPlayer.isPlaying()) {
                    runOnUiThread(() -> {
                        int cur = musicPlayer.getCurrentPosition();
                        tvTime.setText(millisecondsToString(cur));
                        seekBarTime.setProgress(cur);
                    });
                }
                try { Thread.sleep(1000); }
                catch (InterruptedException ignored) {}
            }
        }).start();
    }

    /**
     * Naloži in predvajaj pesem na položaju pos v seznamu songs.
     */
    private void playSongAt(int pos) {
        Song s = songs.get(pos);
        tvTitle.setText(s.getTitle());
        try {
            musicPlayer.reset();
            musicPlayer.setDataSource(s.getPath());
            musicPlayer.prepare();
            musicPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // UI posodobitve
        btnPlay.setBackgroundResource(R.drawable.ic_pause);
        String dur = millisecondsToString(musicPlayer.getDuration());
        tvDuration.setText(dur);
        seekBarTime.setMax(musicPlayer.getDuration());
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnPlay) {
            // play/pause
            if (musicPlayer.isPlaying()) {
                musicPlayer.pause();
                btnPlay.setBackgroundResource(R.drawable.ic_play);
            } else {
                musicPlayer.start();
                btnPlay.setBackgroundResource(R.drawable.ic_pause);
            }

        } else if (id == R.id.btnNext) {
            // naslednja
            position = (position + 1) % songs.size();
            playSongAt(position);

        } else if (id == R.id.btnPrev) {
            // prejšnja
            position = (position - 1 + songs.size()) % songs.size();
            playSongAt(position);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            if (musicPlayer != null && musicPlayer.isPlaying()) {
                musicPlayer.stop();
            }
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Pretvori milisekunde v "m:ss".
     */
    private String millisecondsToString(int time) {
        int minutes = time / 1000 / 60;
        int seconds = time / 1000 % 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (musicPlayer != null) {
            musicPlayer.release();
            musicPlayer = null;
        }
    }
}
